# Trader Control Android App

This is a build-ready Android Studio project for controlling an MT5 robot through the companion VPS service.

## Features
- Start robot
- Stop robot
- VPS/robot status
- Account balance/equity endpoint display
- Open trades endpoint display
- Trade alerts endpoint display
- Editable HTTPS VPS URL and API key
- Android notification permission support

## Build the APK
1. Open the `android-app` folder in Android Studio.
2. Let Gradle sync and install the Android SDK requested by `compileSdk 35` if needed.
3. Select **Build > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

## Configure
Open the app, enter your VPS HTTPS URL and API key, then press **SAVE SETTINGS**.

Do not put broker passwords, private keys, or VPS SSH passwords in the app.
