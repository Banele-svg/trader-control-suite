package com.example.tradercontrol

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.util.Base64
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var account: TextView
    private lateinit var trades: TextView
    private lateinit var alerts: TextView
    private lateinit var baseUrlInput: EditText
    private lateinit var apiKeyInput: EditText
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("trader_control", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "Trader Control"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, lp())

        val subtitle = TextView(this).apply {
            text = "Secure MT5 VPS controller"
            gravity = Gravity.CENTER
            textSize = 15f
        }
        root.addView(subtitle, lp(0, 12))

        status = section("VPS / ROBOT STATUS")
        account = section("ACCOUNT")
        trades = section("OPEN TRADES")
        alerts = section("TRADE ALERTS")
        root.addView(status); root.addView(account); root.addView(trades); root.addView(alerts)

        val start = button("▶  START ROBOT") { command("start") }
        val stop = button("■  STOP ROBOT") { command("stop") }
        val refresh = button("↻  REFRESH") { refresh() }
        root.addView(start); root.addView(stop); root.addView(refresh)

        val settingsTitle = TextView(this).apply {
            text = "CONNECTION SETTINGS"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 28, 0, 10)
        }
        root.addView(settingsTitle)

        baseUrlInput = EditText(this).apply {
            hint = "https://your-vps-domain.example"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("base_url", "https://YOUR_VPS_DOMAIN"))
        }
        root.addView(baseUrlInput, lp())

        apiKeyInput = EditText(this).apply {
            hint = "API key placeholder"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(loadApiKey())
        }
        root.addView(apiKeyInput, lp())

        root.addView(button("SAVE SETTINGS") {
            prefs.edit().putString("base_url", baseUrlInput.text.toString().trim().removeSuffix("/")).apply()
            saveApiKey(apiKeyInput.text.toString())
            toast("Settings saved")
            refresh()
        })

        val note = TextView(this).apply {
            text = "Security: use HTTPS on the VPS. Never paste broker passwords or private keys into this app."
            textSize = 13f
            setPadding(0, 14, 0, 20)
        }
        root.addView(note)
        setContentView(scroll)
    }

    private fun section(label: String): TextView = TextView(this).apply {
        text = "$label\nWaiting..."
        textSize = 16f
        setPadding(0, 14, 0, 14)
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { action() }
        isAllCaps = false
    }

    private fun lp(top: Int = 6, bottom: Int = 6) = LinearLayout.LayoutParams(-1, -2).apply {
        setMargins(0, top, 0, bottom)
    }

    private fun command(action: String) {
        status.text = "VPS / ROBOT STATUS\nSending $action..."
        thread {
            val path = if (action == "start") "/api/robot/start" else "/api/robot/stop"
            val result = request("POST", path)
            handler.post { status.text = "VPS / ROBOT STATUS\n$result"; refresh() }
        }
    }

    private fun refresh() {
        thread {
            val s = request("GET", "/api/status")
            val a = request("GET", "/api/account")
            val t = request("GET", "/api/trades")
            val al = request("GET", "/api/alerts")
            handler.post {
                status.text = "VPS / ROBOT STATUS\n$s"
                account.text = "ACCOUNT\n$a"
                trades.text = "OPEN TRADES\n$t"
                alerts.text = "TRADE ALERTS\n$al"
            }
        }
    }

    private fun request(method: String, path: String): String {
        return try {
            val base = prefs.getString("base_url", "https://YOUR_VPS_DOMAIN")!!.trim().removeSuffix("/")
            val key = loadApiKey()
            if (base.contains("YOUR_VPS_DOMAIN") || key == "CHANGE_ME") return "Configure VPS URL and API key first"
            val conn = (URL(base + path).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 7000
                readTimeout = 7000
                setRequestProperty("Authorization", "Bearer $key")
                setRequestProperty("Accept", "application/json")
                if (method == "POST") setRequestProperty("Content-Type", "application/json")
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            conn.disconnect()
            "$code $body"
        } catch (e: Exception) { "Connection error: ${e.message ?: "unknown error"}" }
    }


    private fun getSecretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val alias = "TraderControlApiKey"
        val existing = ks.getKey(alias, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setUserAuthenticationRequired(false)
            .build())
        return generator.generateKey()
    }

    private fun saveApiKey(value: String) {
        if (value.isEmpty()) return
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
        val encrypted = Base64.encodeToString(cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8)), Base64.NO_WRAP)
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        prefs.edit().putString("api_cipher", encrypted).putString("api_iv", iv).apply()
    }

    private fun loadApiKey(): String {
        return try {
            val encrypted = prefs.getString("api_cipher", null) ?: return "CHANGE_ME"
            val iv = Base64.decode(prefs.getString("api_iv", ""), Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(Base64.decode(encrypted, Base64.NO_WRAP)), StandardCharsets.UTF_8)
        } catch (_: Exception) { "CHANGE_ME" }
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel("trades", "Trade Alerts", NotificationManager.IMPORTANCE_DEFAULT))
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
