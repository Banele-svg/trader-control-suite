#property strict
#property version   "1.00"
#property description "Trader Control Bridge: start/stop flag + status/trades export template"

input string BridgeFolder = "TraderControl"; // Common\\Files\\TraderControl
input int    PollSeconds  = 2;
input bool   UseCommonFolder = true;

bool RobotEnabled = true;
string CommandFile = "desired_state.json";
string StateFile = "state.json";
string TradesFile = "trades.json";

string ReadText(string file_name)
{
   int flags = FILE_READ|FILE_TXT|FILE_ANSI;
   if(UseCommonFolder) flags |= FILE_COMMON;
   int h = FileOpen(BridgeFolder + "\\" + file_name, flags);
   if(h == INVALID_HANDLE) return "";
   string s = FileReadString(h);
   FileClose(h);
   return s;
}

void WriteText(string file_name, string text)
{
   int flags = FILE_WRITE|FILE_TXT|FILE_ANSI;
   if(UseCommonFolder) flags |= FILE_COMMON;
   int h = FileOpen(BridgeFolder + "\\" + file_name, flags);
   if(h == INVALID_HANDLE) return;
   FileWriteString(h, text);
   FileClose(h);
}

void ReadCommand()
{
   string s = ReadText(CommandFile);
   if(StringFind(s, "\"enabled\": true") >= 0 || StringFind(s, "\"enabled\":true") >= 0)
      RobotEnabled = true;
   if(StringFind(s, "\"enabled\": false") >= 0 || StringFind(s, "\"enabled\":false") >= 0)
      RobotEnabled = false;
}

string JsonEscape(string s)
{
   StringReplace(s, "\\", "\\\\");
   StringReplace(s, "\"", "\\\"");
   return s;
}

void PublishState()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   string currency = AccountInfoString(ACCOUNT_CURRENCY);
   string state = StringFormat(
      "{\"robotEnabled\":%s,\"mt5Connected\":true,\"balance\":%.2f,\"equity\":%.2f,\"currency\":\"%s\",\"updated\":%I64d}",
      RobotEnabled ? "true" : "false", balance, equity, JsonEscape(currency), (long)TimeLocal());
   WriteText(StateFile, state);
}

void PublishTrades()
{
   string out = "{\"trades\":[";
   bool first = true;
   for(int i=0; i<PositionsTotal(); i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket)) continue;
      if(!first) out += ",";
      first = false;
      string symbol = PositionGetString(POSITION_SYMBOL);
      long type = PositionGetInteger(POSITION_TYPE);
      double volume = PositionGetDouble(POSITION_VOLUME);
      double profit = PositionGetDouble(POSITION_PROFIT);
      double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      out += StringFormat("{\"ticket\":%I64u,\"symbol\":\"%s\",\"type\":%d,\"volume\":%.2f,\"openPrice\":%.5f,\"profit\":%.2f}", ticket, JsonEscape(symbol), type, volume, openPrice, profit);
   }
   out += "]}";
   WriteText(TradesFile, out);
}

int OnInit()
{
   EventSetTimer(MathMax(1, PollSeconds));
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTimer()
{
   ReadCommand();
   PublishState();
   PublishTrades();
   // IMPORTANT: connect RobotEnabled to your strategy EA's trade permission.
}

void OnTick()
{
   // The bridge intentionally does not place trades.
}
