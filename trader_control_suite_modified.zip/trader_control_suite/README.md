# Trader Control Suite — Android + VPS + MT5 Bridge

Updated version 1.1: the Android client is now a dependency-light Android Studio project using the platform `Activity` API, has editable HTTPS connection settings, encrypts the API key at rest with Android Keystore AES-GCM, and includes a GitHub Actions workflow that can build an installable APK.

## Android features
- Start Robot
- Stop Robot
- VPS/robot status
- Open trades
- Balance/equity
- Trade alerts
- HTTPS API connection
- API key encrypted at rest using Android Keystore
- No broker password, VPS password, SSH private key, or private key is included

## Build the APK
Open `android-app` in Android Studio and use **Build > Build APK(s)**. The debug APK will appear at `android-app/app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, upload the project to a GitHub repository and run the manually triggered **Build Android APK** workflow under Actions. It publishes the APK as a workflow artifact.

## VPS
Copy `config/example.env` to `.env` on your VPS, generate a long random API key, install the Python requirements, and run the service behind HTTPS. Never commit `.env`.

## MT5
Compile and attach `vps-service/mt5-bridge/TraderControlBridge.mq5` in MetaEditor. The bridge is a control/status template and does not contain a trading strategy.

## Safety
Test on a demo account first. A mobile control app cannot guarantee execution during VPS, MT5, broker, network, or EA failures.
