# Trader Control — GitHub phone-only APK build

This package is prepared for building the Android APK from an Android phone using GitHub Actions.

## What to upload
1. Create a GitHub repository.
2. Upload `trader-control-source.zip` to the repository root.
3. Create `.github/workflows/` and upload `build-apk.yml` there.
4. Open the **Actions** tab → **Build Trader Control APK** → **Run workflow**.
5. When complete, open the run → **Artifacts** → `trader-control-debug-apk` → download.
6. Extract the downloaded artifact and install `app-debug.apk` on Android.

No passwords, private keys, or broker credentials are included. Configure the VPS URL and API key inside the app after installation.

Important: this builds a debug APK for testing. Do not use it as a secure production release until the VPS is configured with HTTPS, authentication, and appropriate access controls.
